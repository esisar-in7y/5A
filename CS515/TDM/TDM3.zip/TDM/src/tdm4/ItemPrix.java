package tdm4;
import tdm3.*;
import tdm2.*;

public class ItemPrix implements GetFieldAsInteger<Item>
{

    @Override
    public int getField(Item t) 
    {
    	return t.getPrixHT();
    }

}
