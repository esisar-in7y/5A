package tdm4;

abstract public class Item {
    private String codeBarre;
    private int prixHT;

    public Item(String codeBarre, int prixHT) {
    super();
    this.codeBarre = codeBarre;
    this.prixHT = prixHT;
    }

    public String getCodeBarre() {
    return codeBarre;
    }

    public void setCodeBarre(String codeBarre) {
    this.codeBarre = codeBarre;
    }

    public int getPrixHT() {
    return prixHT;
    }

    public void setPrixHT(int prixHT) {
    this.prixHT = prixHT;
    }
    public String toString() {
        return "Item{" +
               "codeBarre='" + codeBarre + '\'' +
               ", prixHT=" + prixHT +
               '}';
    }
}
