package tdm4;

public interface GetField<T> 
{
    public Integer getField(T t);
}

