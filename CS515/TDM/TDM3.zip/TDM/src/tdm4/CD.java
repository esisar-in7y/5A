package tdm4;

public class CD extends Item {
    private String titre;
    private int nbChansons;

    public CD(String codeBarre, int prixHT, String titre, int nbChansons) {
    super(codeBarre, prixHT);
    this.titre = titre;
    this.nbChansons = nbChansons;
    }

    public String getTitre() {
    return titre;
    }

    public void setTitre(String titre) {
    this.titre = titre;
    }

    public int getNbChansons() {
    return nbChansons;
    }

    public void setNbChansons(int nbChansons) {
    this.nbChansons = nbChansons;
    }

}
