package tdm4;

import java.util.ArrayList;
import java.util.List;

import tdm2.Personne;
import tdm3.GenericFilter2;

public class main {

	public static void main(String[] args) 
	{   
	    List<Livre> ls = new ArrayList<>();
	    ls.add(new Livre("1222", 8, "Les misérables", "Victor Hugo"));
	    ls.add(new Livre("1223", 15, "Guerre et paix", "Leon Tolstoi"));

	    // Récuperer la liste des livres dont le prix est plus petit que 10 euros
	    List<Livre> res = GenericFilter2.filter(ls).lessThan(new ItemPrix(),10).doIt();

		for(Item p:ls) {
			System.out.println(p);
		}
	}

}
