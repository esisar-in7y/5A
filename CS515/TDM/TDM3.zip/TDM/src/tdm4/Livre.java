package tdm4;

public class Livre extends Item {
    private String titre;

    private String auteur;

    public Livre(String codeBarre, int prixHT, String titre, String auteur) {
    super(codeBarre, prixHT);
    this.titre = titre;
    this.auteur = auteur;
    }

    public String getTitre() {
    return titre;
    }

    public void setTitre(String titre) {
    this.titre = titre;
    }

    public String getAuteur() {
    return auteur;
    }

    public void setAuteur(String auteur) {
    this.auteur = auteur;
    }

}
