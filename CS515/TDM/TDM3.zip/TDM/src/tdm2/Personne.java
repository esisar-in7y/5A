package tdm2;

import java.util.ArrayList;
import java.util.List;

public class Personne 
{
    public String nom;
    public String prenom;
    public int age;
    public int revenu;

    public Personne(String nom,String prenom,int age, int revenu)
    {
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.revenu = revenu;
    }       


    static public List<Personne> getAll()
    {
        List<Personne> res = new ArrayList<>();

        res.add(new Personne("AA","Alice",10,0));
        res.add(new Personne("AA","Bob",40,2500));
        res.add(new Personne("CC","Clara",30,1500));
        res.add(new Personne("DD","Dilbert",25,4500));
        res.add(new Personne("EE","Elodie",30,2500));

        return res;
    }

    @Override
    public String toString() {
        return String.format("Personne [nom=%s, prenom='%s', age=%d, revenu=%d]", 
                             nom, prenom, age, revenu);
    }
}
