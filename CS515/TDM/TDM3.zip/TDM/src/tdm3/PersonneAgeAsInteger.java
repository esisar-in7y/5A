package tdm3;

import tdm2.Personne;

public class PersonneAgeAsInteger implements GetFieldAs {
	@Override
	public Integer getField(Object t) {
		Personne pers = (Personne)t;
		return pers.age;
	}
	
}
