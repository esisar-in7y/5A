package tdm3;

import tdm2.Personne;

public class PersonneAgeAsInt implements GetFieldAsInteger {
	@Override
	public int getField(Object t) {
		Personne pers = (Personne)t;
		return pers.age;
	}
	
}
