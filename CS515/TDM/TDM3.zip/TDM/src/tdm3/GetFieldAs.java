package tdm3;

public interface GetFieldAs<T,B> 
{
    public B getField(T t);
}
