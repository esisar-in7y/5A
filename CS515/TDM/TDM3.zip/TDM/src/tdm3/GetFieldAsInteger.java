package tdm3;

public interface GetFieldAsInteger<T> 
{
    public int getField(T t);
}
