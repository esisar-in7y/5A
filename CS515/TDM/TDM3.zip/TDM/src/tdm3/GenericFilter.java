package tdm3;

import java.util.ArrayList;
import java.util.List;

import tdm2.Personne;

interface FilterFunction<T> {
	  Boolean run(T str);
}

public class GenericFilter<T> {
	List<FilterFunction<T>> filters;
	
	public GenericFilter() {
		filters=new ArrayList();
	}
	public List<T> doFilter(List<T> liste){
		List<T> tmp= new ArrayList();
		for(T elem: liste) {
			Boolean isgood=true;
			for(FilterFunction<T> filter: filters) {
				isgood=filter.run(elem);
				if(!isgood) break;
			}
			if(isgood) {
				tmp.add(elem);
			}
		}
		return tmp;
	}
	
	public void filterGreaterThan(GetFieldAsInteger<T> func,int value) {
		FilterFunction<T> lambda = (elem) -> {
			return func.getField(elem) > value;
		};
		filters.add(lambda);
	}
	public void filterLessThan(GetFieldAsInteger<T> func,int value) {
		FilterFunction<T> lambda = (elem) -> {
			return func.getField(elem) < value;
		};
		filters.add(lambda);
	}
}
