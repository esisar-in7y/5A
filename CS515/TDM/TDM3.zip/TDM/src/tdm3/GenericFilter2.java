package tdm3;

import java.util.ArrayList;
import java.util.List;

import tdm2.Personne;


public class GenericFilter2<T> {
	
	private static GenericFilter2 INSTANCE = new GenericFilter2();
	List<FilterFunction<T>> filters;
	List<T> elements;
	

	public GenericFilter2() {
		filters=new ArrayList();
		elements=new ArrayList();
	}
	
	public List<T> doIt(){
		List<T> tmp= new ArrayList();
		for(T elem: elements) {
			Boolean isgood=true;
			for(FilterFunction<T> filter: filters) {
				isgood=filter.run(elem);
				if(!isgood) break;
			}
			if(isgood) {
				tmp.add(elem);
			}
		}
		return tmp;
	}

	public static<T> GenericFilter2<T> filter(List<T> data) {
		GenericFilter2<T> genfilter=new GenericFilter2();
		genfilter.elements=data;
		return genfilter;
	}
	public GenericFilter2<T> greaterThan(GetFieldAsInteger<T> func,int value) {
		FilterFunction<T> lambda = (elem) -> {
			return func.getField(elem) > value;
		};
		filters.add(lambda);
		return this;
	}
	public<B extends T> GenericFilter2<T> lessThan(GetFieldAsInteger<B> func,int value) {
		FilterFunction<T> lambda = (elem) -> {
			return func.getField(elem) < value;
		};
		filters.add(lambda);
		return this;
	}
}
