package tdm3;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class CollectionUtils<T,B> {
	public static<T,B> List<B> selectDistinct(List<T> elements,GetFieldAs<T,B> func) {
		HashSet<B> tmp=new HashSet();
		for(T elem:elements) {
			tmp.add(func.getField(elem));
		}
		return tmp.stream().collect(Collectors.toList());
	}
}
