package tdm3;
import java.util.List;

import tdm2.Personne;

public class exs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Personnes de plus de 27 ans 
		ex3();
	}
	public static void ex1() {
		GenericFilter<Personne> f = new GenericFilter<Personne>();
		f.filterGreaterThan(new PersonneAgeAsInt(),27);  
		List<Personne> ls = f.doFilter(Personne.getAll());
		for(Personne p:ls) {
			System.out.println(p);
		}
	}
	
	public static void ex2() {
		// Personnes plus de 20 ans et ayant un revenu inférieur à 3000 euros
		List<Personne> ls = GenericFilter2
				.filter(Personne.getAll())
				.greaterThan(new PersonneAgeAsInt(),20)
				.lessThan(new PersonneRevenuAsInt(),3000)
				.doIt();
		for(Personne p:ls) {
			System.out.println(p);
		}
	}
	public static void ex3() {
		List<Integer> ls = CollectionUtils.selectDistinct(Personne.getAll(),new PersonneAgeAsInteger());
		for(Integer p:ls) {
			System.out.println(p);
		}
	}

}
