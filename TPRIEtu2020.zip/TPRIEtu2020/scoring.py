search = "Preliminary Report"  # Input search term
words = []

# Read vocabulary from file
with open("vocab") as f:
    for line in f:
        if line.strip():
            words.append(line.strip())

# Prepare search words and IDs
search_words = search.lower().split()
search_ids = []
for w in search_words:
    try:
        search_ids.append(words.index(w))
    except ValueError:
        pass

# Collect document IDs for matching words
have_one = {}
with open("output.txt") as r:
    for line in r:
        word_id, doc_id = (int(i) for i in line.split())
        if word_id in search_ids:
            if word_id not in have_one:
                have_one[word_id] = []
            have_one[word_id].append(doc_id)

# Find common document IDs across all search words
def common_values(dictionary):
    all_values = set(list(dictionary.values())[0])
    common = set(all_values)
    for value in dictionary.values():
        common.intersection_update(value)
    return list(common)

have_all = common_values(have_one)
result = []

# Calculate TF-IDF scores and prepare HTML output
html_output = "<html><head><title>Search Results</title></head><body><h1>Search Results</h1><ul>"
for doc_id in have_all:
    with open(f"Collection/CACM-{doc_id}.stp_df_tf_idf", 'r') as file:
        sum_score = 0
        for line in file:
            word, score = line.split()
            if word in search_words:
                sum_score += float(score)
        
        result.append((sum_score, doc_id))

# Sort results by score
result.sort(reverse=True)

# Generate HTML links for results
for score, doc_id in result:
    link = f'<li><a href="Collection/CACM-{doc_id}.stp_df_tf_idf">Document {doc_id}</a>: Score {score}</li>'
    html_output += link

html_output += "</ul></body></html>"

# Write HTML output to a file
with open("search_results.html", "w") as output_file:
    output_file.write(html_output)

print("Search results have been saved to search_results.html")
