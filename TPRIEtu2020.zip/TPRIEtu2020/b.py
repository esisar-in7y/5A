import glob

words=[]
with open("vocab") as f:
    for line in f:
        if line.strip():
            words.append(line.strip())

for filepath in glob.glob('Collection/*.stp_df'):
    output_filepath=filepath+"_bin"
    with open(filepath) as r:
        current_words=r.read().split()
    counts={}
    for index,word in enumerate(words):
        if word in current_words:
            counts[index]=current_words.count(word)
    with open(output_filepath,"w") as w:
        w.write(" ".join((f"{k}:{v}" for k,v in counts.items())))

    print(f"Bin vector for {filepath} saved to {output_filepath}")