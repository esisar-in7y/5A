search = "Preliminary Report"  # Terme de recherche
words = []

# Lecture du fichier de vocabulaire
with open("vocab") as f:
    for line in f:
        if line.strip():
            words.append(line.strip())

# Préparer les mots de recherche et leurs IDs
search_words = search.lower().split()
search_ids = []
for w in search_words:
    try:
        search_ids.append(words.index(w))
    except ValueError:
        pass

# Collecter les IDs des documents pour les mots correspondants, avec position
have_one = {}
word_positions = {}
with open("output.txt") as r:
    for position,line in enumerate(r):
        word_id, doc_id = (int(i) for i in line.split())
        print(position)
        print(word_id)
        if word_id in search_ids:
            if word_id not in have_one:
                have_one[word_id] = []
                word_positions[word_id] = {}
            have_one[word_id].append(doc_id)
            word_positions[word_id][doc_id] = position  # Stocker la position du mot dans le document
print(have_one)
# Trouver les documents communs à tous les mots recherchés
def common_values(dictionary):
    all_values = set(list(dictionary.values())[0])
    common = set(all_values)
    for value in dictionary.values():
        common.intersection_update(value)
    return list(common)

have_all = common_values(have_one)
result = []

# Fonction pour calculer la proximité des mots dans un document
def calculate_proximity(doc_id, word_positions, search_ids):
    positions = []
    for word_id in search_ids:
        if doc_id in word_positions[word_id]:
            positions.append(word_positions[word_id][doc_id])
    if len(positions) <= 1:
        return 1.0  # Si un seul terme ou pas de proximité à calculer
    positions.sort()
    # Calculer la distance entre les termes, plus proche = meilleure proximité
    proximity = 1.0 / (sum([positions[i+1] - positions[i] for i in range(len(positions)-1)]) + 1)
    return proximity

# Calculer les scores basés sur la proximité et TF-IDF
html_output = "<html><head><title>Search Results</title></head><body><h1>Search Results</h1><ul>"
for doc_id in have_all:
    with open(f"Collection/CACM-{doc_id}.stp", 'r') as file:
        sum_score = 0
        for line in file:
            word, score = line.split()
            if word in search_words:
                sum_score += float(score)
        
        # Calcul de la proximité avec logique floue
        proximity_score = calculate_proximity(doc_id, word_positions, search_ids)
        final_score = sum_score * proximity_score  # Pondérer le score TF-IDF par la proximité
        
        result.append((final_score, doc_id))

# Trier les résultats par score final
result.sort(reverse=True)

# Générer les liens HTML pour les résultats
for score, doc_id in result:
    link = f'<li><a href="Collection/CACM-{doc_id}.stp_df_tf_idf">Document {doc_id}</a>: Score {score:.2f}</li>'
    html_output += link

html_output += "</ul></body></html>"

# Écrire les résultats dans un fichier HTML
with open("search_results_flou_logique.html", "w") as output_file:
    output_file.write(html_output)

print("Les résultats de la recherche ont été enregistrés dans search_results.html")

