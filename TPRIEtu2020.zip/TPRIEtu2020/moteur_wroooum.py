search = "Preliminary Report December"#input("search:")

words=[]
with open("vocab") as f:
    for line in f:
        if line.strip():
            words.append(line.strip())

search_words=search.lower().split()
search_ids=[]
for w in search_words:
    try:
        search_ids.append(words.index(w))
    except:pass

have_one={}
with open("output.txt") as r:
    for line in r:
        word_id,doc_id = (int(i) for i in line.split())
        if word_id in search_ids:
            if not word_id in have_one:
                have_one[word_id]=[]
            have_one[word_id].append(doc_id)

def common_values(dictionary):
    all_values = set(list(dictionary.values())[0])
    common = set(all_values)
    for value in dictionary.values():
        common.intersection_update(value)
    return list(common)

have_all=common_values(have_one)

print(have_all)