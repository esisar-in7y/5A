import glob

output_filepath='output.txt'
liste = []
for filepath in glob.glob('Collection/*.stp_df_bin'):
    print(filepath)
    doc_id = filepath.split("-")[-1].split(".")[0]
    with open(filepath) as r:
        current_words=r.read().split(" ")
        
        for id_count in current_words:
            id,freq = id_count.split(":")
            liste.append((int(id),int(doc_id)))

liste.sort()

with open(output_filepath, 'w') as out_file:
    for id in liste:  
        out_file.write(f"{id[0]} {id[1]}\n")
        