import os
import glob
from collections import Counter

def calculate_tf(directory):
    # Parcourir les fichiers de la collection
    for filename in glob.glob(os.path.join(directory, '*.stp')):
        if os.path.isfile(filename):
            process_file(filename)

def process_file(filepath):
    with open(filepath, 'r') as file:
        word_counts = Counter(file.read().lower().split())
        total_words = sum(word_counts.values())
        
        # Calculer la fréquence des termes (TF)
        tf = {word: count / total_words for word, count in word_counts.items()}
        
        # Sauvegarder la représentation vectorielle dans un fichier
        output_filepath = f"{filepath}_tf"
        with open(output_filepath, 'w') as out_file:
            for word, freq in tf.items():
                out_file.write(f"{word} {freq:.6f}\n")
        
        print(f"TF vector for {filepath} saved to {output_filepath}")

# Utiliser le script
directory = "Collection"  # Dossier contenant les fichiers à traiter
calculate_tf(directory)